 //empirecolors.cs

// stole this from slayer (shhhh)
function rgbToHex(%rgb)
{
	//use % to find remainder
	%r = getWord(%rgb,0);
	if(%r <= 1)
		%r = %r * 255;
	%g = getWord(%rgb,1);
	if(%g <= 1)
		%g = %g * 255;
	%b = getWord(%rgb,2);
	if(%b <= 1)
		%b = %b * 255;
	%a = "0123456789ABCDEF";

	%r = getSubStr(%a,(%r-(%r % 16))/16,1) @ getSubStr(%a,(%r % 16),1);
	%g = getSubStr(%a,(%g-(%g % 16))/16,1) @ getSubStr(%a,(%g % 16),1);
	%b = getSubStr(%a,(%b-(%b % 16))/16,1) @ getSubStr(%a,(%b % 16),1);

	return %r @ %g @ %b;
}

function serverCmdRGBToHex(%c,%r,%g,%b)
{

	if(%r < 256 && %r >= 0 && %g < 256 && %g >= 0 && %b < 256 && %b >= 0)
	{

		%col = rgbToHex(%r SPC %g SPC %b);
		%str = "<color:" @ %col @ ">";
	
		messageClient(%c,'',%str @ %r SPC %g SPC %b SPC "\c6is" SPC %str @ %col SPC "\c6in hex format.");

	}
	else
	{

		messageClient(%c,'',"You must use values under 256 and above 0, cause... rgb. yeaaah.");

	}

}




function serverCmdEmpireColor(%c,%col)
{

	if(strLen(%col) == 6)
	{

		%colStr = "<color:" @ %col @ ">";

		%c.clanPrefix = %colStr @ "•••";
		%c.empireColor = %colStr;

		messageClient(%c,'',"\c6Your empire color is now" @ %colStr SPC %col);

		%gotColor = true;

	}

	if(%col <= 100 && !%gotColor)
	{

		%colFromSet = getColorIDTable(%col-1);

		if(%color !$= "1.000000 0.000000 1.000000 0.000000")
		{

			%colFromSetConv = rgbToHex(%colFromSet);

			%colStr = "<color:" @ %colFromSetConv @ ">";
			%c.empireColor = %colStr;

			messageClient(%c,'',"\c6Your empire color is now" @ %colStr SPC %colFromSetConv);

			%gotColor = true;

		}

	}

	if(%col $= "" && !%gotColor)
	{

		%c.empireColor = "";
		%c.clanPrefix = "";

		messageClient(%c,'',"If you were clearing your color, ignore this. Otherwise, use a number under 100 or a hex code for your empire color. /rgbtohex exists if you need to convert colors from RGB to hex.");

	}

}

function serverCmdEmpireName(%c,%n,%n2,%n3)
{

	if(strLen(%n @ %n2 @ %n3) <= $MerpPref::NameCharLimit && %n !$= "")
	{

		if(%n2 $= ""){ %c.empireName = %n; }
		if(%n3 $= ""){ %c.empireName = %n SPC %n2; }
		if(%n3 !$= ""){ %c.empireName = %n SPC %n2 SPC %n3; }

		messageAll('MsgAdminForce',"\c6" @ %c.name SPC "has named their empire" @ %c.empireColor SPC %c.empireName);

	}
	if(strLen(%n @ %n2 @ %n3) > 1000)
	{

		messageClient(%c,'',"\c6You must use an empire name under" SPC 1000 SPC "characters.");

	}
	if(%n $= "")
	{

		messageClient(%c,'',"\c6You did not specify anything.");

	}

}


package fixThatSymbol
{
	function serverCmdMessageSent(%c,%msg)
	{
		if(getSubStr(%msg,0,1) $= "<")
		{
			messageAll('',%c.empireColor @ "**" @ %c.empireName @ "\c6:" SPC getSubStr(%msg,1,strLen(%msg)));
		}

		else if(getSubStr(%msg,0,1) !$= "<")
		{
			parent::serverCmdMessageSent(%c,%msg);
		}
	}
	function gameConnection::autoAdminCheck(%c)
	{
		Parent::autoAdminCheck(%c);
		messageClient(%c, '' , "\c6This server uses Foxitron's optimized MERP code: /empirecolor [hex or colorset number] :: /empirename [name] :: /rgbtohex [r] [g] [b] ::" NL "\c6 Fox's Added Commands:" SPC " /war [empire name] :: /ceasefire [empire name] :: DONT USE: /traderoute [empire name]")
	}
}
activatePackage(fixThatSymbol);

function serverCmdRoll(%c)
{
	
		%num = getRandom(1,10);
		switch(%num)
		{
			case 1 || 2 || 3 || 4
				messageall('', "\c4" %c.Name SPC "\c6 rolled a" SPC %num SPC "! Bad luck..")
			case 5 || 6
				messageall('', "\c4" %c.Name SPC "\c6 rolled a" SPC  %num SPC  "! Minor damage.")
			case 7 || 8
				messageall('', "\c4" %c.Name SPC "\c6 rolled a" SPC  %num SPC  "! Medium damage!")
			case 9
				messageall('', "\c4" %c.Name SPC "\c6 rolled a" SPC  %num SPC  "! Major damage!")
			case 10
				messageall('', "\c4" %c.Name SPC "\c6 rolled a" SPC  %num SPC  "! Critical HIT!!")
			default
				echo("ERROR WITH COMPUTING function serverCmdroll(%c)! Please report to host.")
		}
	}
}
function serverCmdWar(%c, %v.empireName)
{
	if(%v.empireName $= "")
	{
		messageclient(%c, '', "\c6 You did not specify a player to declare war on.")
	}
	if else(!%v.isObject)
	{
		messageclient(%c, '', "\c6 Either that player has not spawned, or it isn't a player name. Please re-enter it!"
	}
	if else(%c.empireName $= "")
	{
		messageclient(%c, '', "\c6 Please enter your /empirename and /empire color before declaring war!")
	}
	else
	{
		messageall('', %c.empireColor %c.empireName SPC "\c2 has declared war on" SPC %v.empireColor %v.empireName"!")
	}
function serverCmdCeaseFire(%c, %v.empireName)
{
	if(%v.empireName $= "")
	{
		messageclient(%c, '', "\c6 Please specify an empire name to send the treaty to.")
	}
	else
	{
		messageall('', %c.empireColor %c.empireName "\c6 has sent" %v.empireColor %v.empireName "\c6 a peace treaty. Will s/he accept?")
		messageclient(%v, '', %c.empireColor %c.empireName "\c6 has sent you a ceasefire treaty. Accept or decline in RP.")
	}
}